async function cargarProductos() {
  const res = await fetch(`/api/productos`);
  const productos = await res.json();
  const main = document.querySelector("main");
  main.innerHTML = "";
  productos.forEach(p => {
    const card = document.createElement("div");
    card.className = "bg-white shadow rounded p-4";
    card.innerHTML = `
      <img src="${p.imagen}" alt="${p.nombre}" class="rounded mb-2">
      <h2 class="text-lg font-semibold">${p.nombre}</h2>
      <p class="text-gray-500">${p.descripcion}</p>
      <button onclick="addToCart('${p.nombre}')" class="bg-pink-500 text-white px-4 py-2 mt-2 rounded">Agregar al carrito</button>
    `;
    main.appendChild(card);
  });
}

function openLoginModal() {
  document.getElementById("loginModal").classList.remove("hidden");
}

function closeLoginModal() {
  document.getElementById("loginModal").classList.add("hidden");
}

function login() {
  const user = document.getElementById("username").value;
  const pass = document.getElementById("password").value;

  if (user && pass) {
    alert(`Bienvenido, ${user}!`);
    closeLoginModal();
  } else {
    alert("Completa todos los campos.");
  }
}

function addToCart(product) {
  let cart = JSON.parse(localStorage.getItem("cart")) || [];
  cart.push(product);
  localStorage.setItem("cart", JSON.stringify(cart));
  alert(`${product} agregado al carrito.`);
}

function showCart() {
  const modal = document.getElementById("cartModal");
  const cartItems = document.getElementById("cartItems");
  cartItems.innerHTML = "";
  let cart = JSON.parse(localStorage.getItem("cart")) || [];
  cart.forEach((item) => {
    const li = document.createElement("li");
    li.textContent = `• ${item}`;
    cartItems.appendChild(li);
  });
  modal.classList.remove("hidden");
}

function closeCart() {
  document.getElementById("cartModal").classList.add("hidden");
}

function checkout() {
  const method = document.getElementById("paymentMethod").value;
  const cart = JSON.parse(localStorage.getItem("cart")) || [];
  fetch('/api/pago', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ carrito: cart, metodoPago: method })
  }).then(() => {
    alert(`Gracias por tu compra. Has seleccionado pagar con ${method}.`);
    localStorage.removeItem("cart");
    closeCart();
  });
}

document.addEventListener("DOMContentLoaded", cargarProductos);
const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3001;

app.use(cors());
app.use(express.json());

app.use(express.static(path.join(__dirname, '../frontend')));

app.get('/api/productos', (req, res) => {
  const productos = JSON.parse(fs.readFileSync(path.join(__dirname, 'productos.json')));
  res.json(productos);
});

app.post('/api/pago', (req, res) => {
  const { carrito, metodoPago } = req.body;
  console.log('Compra:', carrito, metodoPago);
  res.json({ mensaje: `Compra con ${metodoPago} recibida.` });
});

app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/index.html'));
});

app.listen(PORT, () => {
  console.log(`Servidor activo en http://localhost:${PORT}`);
});